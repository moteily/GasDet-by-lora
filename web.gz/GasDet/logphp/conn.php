
<?php
/*****************************
*数据库连接
*****************************/


$conn = mysqli_connect(SAE_MYSQL_HOST_M.':'.SAE_MYSQL_PORT,SAE_MYSQL_USER,SAE_MYSQL_PASS);


if (!$conn){
	die("连接数据库失败：" . mysql_error());
}
 mysqli_select_db($conn,SAE_MYSQL_DB);
//字符转换，读库
mysqli_query($conn,"set character set 'gbk'");
//写库
mysqli_query($conn,"set names 'gbk'");
?>