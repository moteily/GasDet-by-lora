<?php
session_start();

//注销登录
if($_GET['action'] == "logout"){
	//unset($_SESSION['userid']);
	unset($_SESSION['username']);
	echo '注销登录成功！点击此处 <a href="http://1.gasdetect.applinzi.com/GasDet/logon.html">登录</a>';
	exit;
}
if(!isset($_POST['submit'])){
	exit('非法访问!');
}
//登录

$username = htmlspecialchars($_POST['username']);
$password  = $_POST['password'];
$password= substr(MD5($password),8,16);  //md5加密

//包含数据库连接文件
include('conn.php');
//检测用户名及密码是否正确
$sql1="select username from LogReg where username='$username' limit 1";  //检测用户名
$sql2="select username from LogReg where username='$username' and password='$password' limit 1";  //检测用户名及密码
$check_query1 = mysqli_query($conn,$sql1);
$check_query2 = mysqli_query($conn,$sql2);
if(mysqli_fetch_array($check_query1)){
    if(mysqli_fetch_array($check_query2)){
	//登录成功
	$_SESSION['username'] = $username;
	//$_SESSION['userid'] = $result['uid'];
	echo $username,' 欢迎你！进入 <a href="http://1.gasdetect.applinzi.com/GasDet/chartonline.html">用户中心</a><br />';
	echo '点击此处 <a href="login.php?action=logout">注销</a> 登录！<br />';
	exit;
    }else{
        exit('密码错误，登录失败！点击此处 <a href="javascript:history.back(-1);">返回</a> 重试');        
    }
} else {
	exit('用户不存在，登录失败！点击此处 <a href="javascript:history.back(-1);">返回</a> 重试');
}
?>