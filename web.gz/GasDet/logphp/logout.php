<?php
session_start();

//注销登录
if($_GET['action'] == "logout"){
	//unset($_SESSION['userid']);
	unset($_SESSION['username']);
	echo '注销登录成功！点击此处 <a href="http://1.gasdetect.applinzi.com/GasDet/index.html">登录</a>';
	exit;
}
if(!isset($_POST['submit'])){
	exit('非法访问!');
}
?>