<?php header('content-type: '); ?>
<?php
error_reporting(E_ALL ^ E_NOTICE);
require_once 'OperateMysql.php';
$phpGasDet = new OperateMysql();
$conn = $phpGasDet->Connect_Mysql();

$sql = "SELECT * FROM Sensor1_Det ORDER BY Time DESC LIMIT 8";
$result = $phpGasDet -> Query_Mysql($sql, $conn) or die("查询失败");
//$canshu=array("draw"=>"1","length"=>"9","recordsTotal"=>"24","recordsFiltered"=>"24"); //headers

//$draw=1;
//$length=8;
//$recordsTotal = 24;
//$recordsFiltered = 24;
//定义变量json存储值
	$datas="";
    $data= array();
	$array= array();
	class GasDet{
		public $Num;
        public $SensorNum;
	    public $Location;
	    public $Destiny;
		public $Time;
        public $Danger;
	
	}

while ($RowData = mysqli_fetch_row($result))
	{ 
		list($Num,$SensorNum,$Location,$Destiny,$Time) = $RowData;   
  	    $Mot = new GasDet();
        $Mot->Num = $Num;
        $Mot->SensorNum = $SensorNum;
        $Mot->Location = $Location;
        $Mot->Destiny = $Destiny;
        $Mot->Time = $Time;
       if($Destiny<="75")
        {
          $Mot->Danger = "No";
        }
        else if($Destiny>"75")
        {
          $Mot->Danger = "Yes";
        }
		
		$array[] = $Mot;//数组赋值
	};
    $data0=array("draw"=>1,"recordsTotal"=>8,"recordsFiltered"=>8,"data"=>$array); //headers
   // $data0=array("draw"=>1,"recordsTotal"=>240,"recordsFiltered"=>240,"data"=>$array); //headers
   // $data=$array;
    //$data=array_merge($canshu,$data);  
 
	$datas = json_encode($data0);
   
 //     $data = substr($data,1,strlen($str)-1); 
	echo $datas;
$conn->close();
?>