<?php
require_once 'OperateMysql.php';
$Release = new OperateMysql();
$conn = $Release->Connect_Mysql();
$sql =  "ALTER TABLE Sensor0_Det alter COLUMN DangerRelease SET DEFAULT 0";  //修改默认值为0；;
$result = $Release -> Query_Mysql($sql, $conn) or die("消除警告失败");
echo '消除一号节点警报成功，短信通知业务回复！点击此处 <a href="http://1.gasdetect.applinzi.com/GasDet/tableonline.html">返回</a>';
?>