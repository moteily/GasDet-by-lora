<?php

$Num= $_POST['Num'];
$SensorNum = $_POST['SensorNum'];
$Location= $_POST['Location'];
$Destiny= $_POST['Destiny'];
$Time= $_POST['Time'];
$Voltage= $_POST['Voltage'];
/*
$Num='1';
$SensorNum = '2';
$Location= 'weihai';
$Destiny= '30';
$Time= '20';
*/
$conn = mysqli_connect(SAE_MYSQL_HOST_M.':'.SAE_MYSQL_PORT,SAE_MYSQL_USER,SAE_MYSQL_PASS);

if(! $conn )
{
    die('连接失败: ' . mysqli_error($conn));
}
echo '连接成功<br />';

  mysqli_select_db($conn,SAE_MYSQL_DB);
  $sql = "INSERT INTO Sensor0_Det (Num,SensorNum,Location,Destiny,Time,Voltage) VALUES('$Num','$SensorNum','$Location','$Destiny','$Time','$Voltage')";
  $result = mysqli_query($conn,$sql) or die(mysqli_error($conn));
  echo($result);


//CREATE TABLE GasDet (Num CHAR(9) PRIMARY KEY,Location CHAR(10) UNIQUE,Destiny CHAR(10))

//INSERT INTO GasDet (Num,Location,Destiny) VALUES('02','Jinan','30')
//SELECT * FROM 'GasDet'
//INSER INTO GasDet (Num,Location,Destiny) VALUES("01","Qingdao","20")
//mysqli_select_db( $conn, 'GasDet' );



?>