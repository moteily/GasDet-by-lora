<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require_once 'OperateMysql.php';
$phpGasDet = new OperateMysql();
$conn = $phpGasDet->Connect_Mysql();

$sql = "SELECT * FROM Sensor0_Det ORDER BY Time DESC LIMIT 8";
$result = $phpGasDet -> Query_Mysql($sql, $conn) or die("查询失败");
$flag = 0; 

//定义变量json存储值
	$data="";
	$array= array();
	class GasDet{
		public $Num;
        public $SensorNum;
	    public $Location;
	    public $Destiny;
		public $Time;
        public $Danger;
        public $DangerRelease;
	
	}
    class User{
            public $username;
            public $password;
            public $email;
            public $regdate;
            public $phone;

        }
while ($RowData = mysqli_fetch_row($result))
	{ 
		list($Num,$SensorNum,$Location,$Destiny,$Time,$DangerRelease) = $RowData;   
  	    $Mot = new GasDet();
        $Mot->Num = $Num;
        $Mot->SensorNum = $SensorNum;
        $Mot->Location = $Location;
        $Mot->Destiny = $Destiny;
        $Mot->Time = $Time;
        $Mot->DangerRelease = $DangerRelease;
       if($Destiny<="150")
        {
          $Mot->Danger = "No";
        }
        else if($Destiny>"150")
        {
          $Mot->Danger = "Yes";
             
            //echo $DangerRelease;
            //echo $flag;
             if(($DangerRelease == 0)&&($flag == 0))  //仍处于危险状态,DanggerRelease 初始默认值为1;  取一次值有危险只发短信通知一次。
             {    
                    $users = $_SESSION['username'];  //获取当前的登陆的用户名
                    $MessageDanger = new OperateMysql();
                   // echo $users;
                    $conn2 = $MessageDanger->Connect_Mysql();
                    $sql2 = "SELECT * FROM LogReg WHERE username = '$users' "; 
                    $result2 = $MessageDanger -> Query_Mysql($sql2, $conn2) or die("查询失败");
                    //$result2 = mysqli_query($conn2,$sql2);
                 //echo $result2;
                   $RowData2 = mysqli_fetch_row($result2);
                   list($username,$password,$email,$regdate,$phonenumber) = $RowData2;
                   //echo $phonenumber;
                  
                    $statusStr = array(
                            "0" => "短信发送成功",
                            "-1" => "参数不全",
                            "-2" => "服务器空间不支持,请确认支持curl或者fsocket，联系您的空间商解决或者更换空间！",
                            "30" => "密码错误",
                            "40" => "账号不存在",
                            "41" => "余额不足",
                            "42" => "帐户已过期",
                            "43" => "IP地址限制",
                            "50" => "内容含有敏感词"
                        );	
                    $smsapi = "http://www.smsbao.com/"; //短信网关
                    $user = "moteily"; //短信平台帐号
                    $pass = md5("460716687"); //短信平台密码
                    $content="【GasDet】 1号传感器节点附近有漏气现象，请及时处dsadsadsadsadasdadas理。";//要发送的短信内容
                    $phone = $phonenumber;
                    $sendurl = $smsapi."sms?u=".$user."&p=".$pass."&m=".$phone."&c=".urlencode($content);
                    $flag = 1;//只发送一次短信;
                    $sql3 = "ALTER TABLE Sensor0_Det alter COLUMN DangerRelease SET DEFAULT 1";  //修改数据库DangerRelease变量默认值为0,需要管理员网页端恢复。
                    $result3 = $phpGasDet -> Query_Mysql($sql3, $conn) or die("查询失败");
                  //ALTER TABLE Sensor0_Det alter COLUMN DangerRelease SET DEFAULT 0  修改默认值为0；
                    file_get_contents($sendurl) ;
                    
                    //$DangerRelease=0;   //   ALTER TABLE Sensor0_Det alter COLUMN DangerRelease SET DEFAULT 0  修改默认值为0；
    
             }
         
             
        }
		
		$array[] = $Mot;//数组赋值
	}
 
	$data = json_encode($array);
   
 //     $data = substr($data,1,strlen($str)-1); 
	echo $data;
    
$conn->close();
?>