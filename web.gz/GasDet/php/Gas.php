<?php header('content-type: '); ?>
<?php
error_reporting(E_ALL ^ E_NOTICE);
require_once 'OperateMysql.php';
$phpGasDet = new OperateMysql();
$conn = $phpGasDet->Connect_Mysql();

$sql = "SELECT * FROM GasDet ORDER BY Num  LIMIT 8";
$result = $phpGasDet -> Query_Mysql($sql, $conn) or die("查询失败");

//定义变量json存储值
	$data="";
	$array= array();
	class GasDet{
		public $Num;
	    public $Location;
	    public $Destiny;
		public $Time;
	
	}
while ($RowData = mysqli_fetch_row($result))
	{ 
		list($Num,$Location,$Destiny,$Time) = $RowData;   
  	    $Mot = new GasDet();
        $Mot->Num = $Num;
        $Mot->Location = $Location;
        $Mot->Destiny = $Destiny;
        $Mot->Time = $Time;
		
		$array[] = $Mot;//数组赋值
	}
 
	$data = json_encode($array);
   
 //     $data = substr($data,1,strlen($str)-1); 
	echo $data;
$conn->close();
?>