<?php

$Num= $_POST['Num'];
$Location= $_POST['Location'];
$Destiny= $_POST['Destiny'];
$Time= $_POST['Time'];

$conn = mysqli_connect(SAE_MYSQL_HOST_M.':'.SAE_MYSQL_PORT,SAE_MYSQL_USER,SAE_MYSQL_PASS);

if(! $conn )
{
    die('连接失败: ' . mysqli_error($conn));
}
echo '连接成功<br />';

    mysqli_select_db($conn,SAE_MYSQL_DB);
if($Num )
{
  $sql = "INSERT INTO GasDet (Num,Location,Destiny,Time) VALUES('$Num','$Location','$Destiny','$Time')";
  $result = mysqli_query($conn,$sql) or die(mysqli_error($conn));
}

//CREATE TABLE GasDet (Num CHAR(9) PRIMARY KEY,Location CHAR(10) UNIQUE,Destiny CHAR(10))

//INSERT INTO GasDet (Num,Location,Destiny) VALUES('02','Jinan','30')
//SELECT * FROM 'GasDet'
//INSER INTO GasDet (Num,Location,Destiny) VALUES("01","Qingdao","20")
//mysqli_select_db( $conn, 'GasDet' );



?>